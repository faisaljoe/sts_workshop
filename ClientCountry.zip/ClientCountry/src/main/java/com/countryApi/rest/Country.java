package com.countryApi.rest;

import java.util.Arrays;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

public class Country {
  
  private Integer id;
  private String name;
  private String[] currencies;
  private String region;
  private String subregion;
  
  public Country() {
    
  }

  public Country(Integer id, String name, String[] currencies, String region, String subgregion) {
    super();
    this.id = id;
    this.name = name;
    this.currencies = currencies;
    this.region = region;
    this.subregion = subgregion;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
  
  public String[] getCurrrencies() {
	 return currencies;
  }

  public void setCurrencies(String[] currencies) {
    this.currencies = currencies;
  }

  public String getRegion() {
		 return region;
  }

  public void setRegion(String region) {
	    this.region = region;
  }
  
  public String getSubRegion() {
		 return subregion;
  }

public void setSubregion(String subregion) {
	    this.subregion = subregion;
  }

  
  @Override
  public String toString() {
    return "Country [id=" + id + ", name=" + name + ", currencies=" + Arrays.toString(currencies) + ", region=" + region 
        + ", subregion=" + subregion + "]";
  }
  
}

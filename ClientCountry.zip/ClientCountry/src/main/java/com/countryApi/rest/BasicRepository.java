package com.countryApi.rest;

import org.springframework.data.repository.CrudRepository;

public interface BasicRepository extends CrudRepository<CountryList, Integer> {
  

}
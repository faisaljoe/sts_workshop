DROP TABLE IF EXISTS `countrylist`;
CREATE TABLE `countrylist` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `region` varchar(255) DEFAULT NULL,
  `subregion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);


package com.countrylist.jpa.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.countrylist.jpa.dto.CountryDTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter @Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString

@Entity
@Table(name="countrylist")
public class Country {
  
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;
  private String name;
  private String currency;
  private String region;
  private String subregion;

  
  public Country (CountryDTO cntyDTO) {
    
    this.name = cntyDTO.getName();
    this.currency = cntyDTO.getCurrency();
    this.region = cntyDTO.getRegion();
    this.subregion = cntyDTO.getSubregion();
  }
  
}

package com.countrylist.jpa.exception;

public class IncorrectURLFormatException extends RuntimeException {
  
  public IncorrectURLFormatException(String message) {
    super(message);
  }


}
package com.countrylist.jpa.dto;

import com.countrylist.jpa.model.Country;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter @Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class CountryDTO {
  
  private Integer id;
  private String name;
  private String currency;
  private String region;
  private String subregion;

  public CountryDTO(Country ctry) {
	    this.id = ctry.getId();
	    this.name = ctry.getName();
	    this.currency = ctry.getCurrency();
	    this.region = ctry.getRegion();
	    this.subregion = ctry.getSubregion();
	  }
}

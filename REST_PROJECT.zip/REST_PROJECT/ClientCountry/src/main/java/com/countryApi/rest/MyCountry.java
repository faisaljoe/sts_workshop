package com.countryApi.rest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.countryApi.rest.Country;


//import com.countryApi.rest.BasicRepository;

//import org.springframework.data.repository.CrudRepository;

@Component
public class MyCountry implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(MyCountry.class);

    @Autowired
    private MyRestService myRestService;
    
    @Autowired
    private BasicRepository cntyRepo;

    @Override
    public void run(String... args) throws Exception {
    	
      
      Country cnty = null;
      Country[] cntys = null;
    
      
      //Country cnty1 = new Country(0,"Bogota",new String[] {"BGT"},"Africa","West Africa");
      //Country cnty2 = new Country(0,"Finland",new String[] {"EUR"},"Europe","West Europe");
       
      logger.info("Started MyCountry");
      
      //cntyRepo.save(cnty1);
      
      //waitKeyPress();
      
      cntys = myRestService.getAllCountry();

      logger.info("Retrieved " + cntys.length + " country ..");
      //showCountry(cntys);
      saveCountry(cntys);
      
      
      //waitKeyPress()

      //waitKeyPress();
      
      logger.info("Application complete !");
    }
    
    private void showCountry(Country[] cntys) {
      for (Country cnty: cntys) {
        logger.info(cnty.toString());
      }
    }
    
    private void saveCountry(Country[] cntys) {
        for (Country cnty: cntys) {
        	
        	 cntyRepo.save(cnty);
          logger.info(cnty.toString());
        }
      }
    
    //public void saveCountry(CountryDTO cntyDTO) {
        
      
     //     Country newCnty = new Country(cntyDTO);
     //     cntyRepo.save(newCnty);
     // }
    
    private void waitKeyPress() {
      logger.info("Press enter to continue ....");
      Scanner scanner = new Scanner(System.in);
      scanner.nextLine();
      logger.info("\n");
      //scanner.close();
    }
}
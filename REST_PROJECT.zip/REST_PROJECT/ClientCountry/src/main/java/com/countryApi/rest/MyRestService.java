package com.countryApi.rest;

import java.net.URI;


import java.net.URISyntaxException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.countryApi.rest.Country;

@Service
public class MyRestService {

  private static final Logger logger = LoggerFactory.getLogger(MyRestService.class);

  @Autowired
  private RestTemplate myRestTemplate;
  
  @Autowired
  private BasicRepository cntyRepo;
  
  @Value("${myrest.url}")
  private String restUrl;
  
  @Value("${rapidapi.key}")
  private String rapidapikey;
  
  // GET Country list from Public API
  public Country[] getAllCountry() {
    
    String finalUrl = restUrl + rapidapikey;
    logger.info("GET to " + finalUrl);
    
   
    return myRestTemplate.getForObject(finalUrl, Country[].class);
    
  }
}
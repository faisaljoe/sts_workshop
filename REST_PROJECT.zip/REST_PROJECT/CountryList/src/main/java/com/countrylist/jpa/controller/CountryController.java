package com.countrylist.jpa.controller;

import java.net.URI;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.countrylist.jpa.service.CountryService;
import com.countrylist.jpa.dto.CountryDTO;
import com.countrylist.jpa.exception.IncorrectURLFormatException;


import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api")
public class CountryController {
  
  @Autowired
  CountryService cntyService;
  
  //@GetMapping("/country")
  //public List<CountryDTO> getAllCountry() {
    
  //  log.info("GET /api/country invoked");
  //  return cntyService.getAllCountry();
    
  //}
  
  @GetMapping("/country")
  public List<CountryDTO> getAllCountry(@RequestParam Map<String, String> allParams) {

    log.info("GET /api/country invoked");
    
    return cntyService.getWithParams(allParams);
  }
  
  @PostMapping("/country")
  public ResponseEntity<Object> addSingleCountry(@RequestBody CountryDTO cntyDTO) {
    
    log.info("POST /api/country invoked");
    
    int cntyId = cntyService.saveCountry(cntyDTO);
    URI location = ServletUriComponentsBuilder.fromCurrentRequest()
        .path("/{id}")
        .buildAndExpand(cntyId)
        .toUri();   
    return ResponseEntity.created(location).build();
    
  }  
  
  @PutMapping("/country/{cntyIdString}")
  public void updateCountry(@PathVariable String cntyIdString, @RequestBody CountryDTO cntyDTO) {

    log.info("PUT /api/country invoked");
    
    int cntyId = 0;
    try {
      cntyId = Integer.parseInt(cntyIdString);
    } catch (NumberFormatException ex) {
      throw new IncorrectURLFormatException("Country id specified in path must be a number");
    }
    cntyService.updateCountry(cntyId, cntyDTO);

  }
  
  @DeleteMapping("/country/{cntyIdString}")
  public void deleteCountry(@PathVariable String cntyIdString) {

    log.info("DELETE /api/country invoked");
    
    int cntyId = 0;
    try {
      cntyId = Integer.parseInt(cntyIdString);
    } catch (NumberFormatException ex) {
      throw new IncorrectURLFormatException("Country id specified in path must be a number");
    }
    cntyService.deleteCountry(cntyId);
    
  }
  
  @GetMapping("/country/{cntyIdString}")
  public CountryDTO getSingleCountry(@PathVariable String cntyIdString) {

    log.info("GET /api/country/" + cntyIdString + " invoked");

    Integer cntyId = null;
    try {
    	cntyId = Integer.parseInt(cntyIdString);
    } catch (NumberFormatException ex) {
      throw new IncorrectURLFormatException("Country id specified in path must be a number");
    }
    return (cntyService.getSingleCountry(cntyId));

  }

}

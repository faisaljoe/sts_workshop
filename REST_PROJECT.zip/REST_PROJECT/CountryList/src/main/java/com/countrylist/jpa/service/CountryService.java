package com.countrylist.jpa.service;

import java.util.ArrayList;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.countrylist.jpa.dto.CountryDTO;
import com.countrylist.jpa.exception.IncorrectJSONFormatException;
import com.countrylist.jpa.exception.IncorrectURLFormatException;
import com.countrylist.jpa.model.Country;
import com.countrylist.jpa.repository.CountryRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CountryService {
  
  @Autowired
  private CountryRepository cntyRepo;
  
  private static final String REGION_PARAM = "region";
  private static final String SUBREGION_PARAM = "subregion";
  private static final String LIMIT_PARAM = "limit";
  private static final String PAGE_PARAM = "page";
  
  
  public List<CountryDTO> getAllCountry() {
    
    Iterable<Country> cntyList = cntyRepo.findAll();
    log.info("Retrieved countries from database");
   
    return convertCountryListToCountryDTOList(cntyList);
  }
  
  public int saveCountry(CountryDTO cntyDTO) {
    
    if (isCountryValid(cntyDTO)) {
      Country newCnty = new Country(cntyDTO);
      cntyRepo.save(newCnty);
    }
    else 
      throw new IncorrectJSONFormatException("JSON is valid, but incorrect format for country");

    List<Country> cnty = cntyRepo.getNewlyAddedRecord();
    int newCntyId = cnty.get(0).getId();
    return newCntyId;
    
  }
  
  public void updateCountry(int cntyId, CountryDTO cntyDTO) {
    
    if (isCountryValid(cntyDTO)) {
      Country newCnty = new Country(cntyDTO);
      if (!cntyRepo.existsById(cntyId))
        throw new IncorrectURLFormatException("Country with id : " + cntyId + " does not exist");
      
      log.info("Updating country id : "+ cntyId);
      log.info("With new contents : " + newCnty.toString());

      cntyRepo.updateExistingRecord(cntyId, newCnty.getName(),newCnty.getRegion(), newCnty.getSubregion());
    }
    else 
      throw new IncorrectJSONFormatException("JSON is valid, but incorrect format for country");
  
  }
  
  
  public void deleteCountry(int cntyId) {
    
      if (!cntyRepo.existsById(cntyId))
        throw new IncorrectURLFormatException("Country with id : " + cntyId + " does not exist");
      
      log.info("Deleting country id : "+ cntyId);

      cntyRepo.deleteById(cntyId);
    
  }
  
  public CountryDTO getSingleCountry(int cntyId) {
    
    if (!cntyRepo.existsById(cntyId))
      throw new IncorrectURLFormatException("Country with id : " + cntyId + " does not exist");

    Optional<Country> cnty = cntyRepo.findById(cntyId);
    return new CountryDTO(cnty.get());
    
  }
  
  
  public List<CountryDTO> getWithParams(Map<String, String> allParams) {
    
    String regionValue = null;
    String subregionValue = null;
    int pageVal = -1;
    int limitVal = -1;
    
    Pageable paging;
    
    List<CountryDTO> listToReturn = new ArrayList<CountryDTO>();
    if (allParams.size() == 0)
      return getAllCountry();
    else {
      
      for (Map.Entry<String, String> entry : allParams.entrySet()) {
        
        String tempKey = entry.getKey();
        String tempValue = entry.getValue();
        log.info(tempKey + " : " + tempValue);
        
        if (tempKey.equals(REGION_PARAM)) {
          
          regionValue = tempValue;
        
        } else if (tempKey.equals(SUBREGION_PARAM)) {
        
          subregionValue = tempValue;
  
        } else if (tempKey.equals(LIMIT_PARAM)) {
          
          try {
            limitVal = Integer.parseInt(tempValue);
          } catch (NumberFormatException ex) {
            throw new IncorrectURLFormatException("limit parameter must be a number");
          }
          if (limitVal < 0)
            throw new IncorrectURLFormatException("limit parameter must be a positive number");          
          
        } else if (tempKey.equals(PAGE_PARAM)) {
          
          try {
            pageVal = Integer.parseInt(tempValue);
          } catch (NumberFormatException ex) {
            throw new IncorrectURLFormatException("page parameter must be a number");
          }
          if (pageVal < 0)
            throw new IncorrectURLFormatException("page parameter must be a positive number");
          
        }
      
      }
      
      if (limitVal >= 0 && pageVal >= 0) {
        
        log.info("Retrieving country from page : " + pageVal + " with a limit of : " + limitVal);
        
        paging = PageRequest.of(pageVal, limitVal);
        List<Country> cnty = cntyRepo.findAll(paging).getContent();
        listToReturn = convertCountryListToCountryDTOList(cnty);
        
      } else if (!(limitVal < 0 && pageVal < 0)) {
        
        throw new IncorrectURLFormatException("both limit and page parameters must be supplied together");
        
      }
      
      
      	if (regionValue != null) {
        
        log.info("Retrieving all countries in region : " +regionValue);
        listToReturn = convertCountryListToCountryDTOList(cntyRepo.findByRegion(regionValue));
      
      } else if (subregionValue != null) {

        log.info("Retrieving all countries in subregion : " +subregionValue);
        listToReturn = convertCountryListToCountryDTOList(cntyRepo.findBySubregion(subregionValue));

      } 

      return listToReturn;

    }
    
  }
  
  private boolean isCountryValid(CountryDTO cntyDTO) {
    
    return (cntyDTO.getName() != null &&
        cntyDTO.getRegion() != null &&
        cntyDTO.getSubregion() != null);
    
  }
  
  private List<CountryDTO> convertCountryListToCountryDTOList(Iterable<Country> cntyList) {
    
    List<CountryDTO> myCnty = new ArrayList<CountryDTO>();
    for (Country cnty : cntyList) {
    	myCnty.add(new CountryDTO(cnty));
    }
   
    return myCnty;
    
  }


}

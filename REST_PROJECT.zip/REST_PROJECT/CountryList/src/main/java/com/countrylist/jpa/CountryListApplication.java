package com.countrylist.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CountryListApplication {

	public static void main(String[] args) {
		SpringApplication.run(CountryListApplication.class, args);
	}

}
